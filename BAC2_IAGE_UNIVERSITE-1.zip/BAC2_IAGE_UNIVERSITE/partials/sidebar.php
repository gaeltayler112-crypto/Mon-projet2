<div id="sidebar">
    <!-- Menu de navigation -->
    <div id="header">
        <h1>Université</h1>
    </div>
    <div id="menu">
        <ul>
            <li><a href="/BAC2_IAGE_UNIVERSITE/index.php">Accueil</a></li>
            <li><a href="/BAC2_IAGE_UNIVERSITE/views/facultes/index.php">Facultés</a></li>
            <li><a href="/BAC2_IAGE_UNIVERSITE/views/niveaux/index.php">Niveaux</a></li>
            <li><a href="/BAC2_IAGE_UNIVERSITE/views/filieres/index.php">Filières</a></li>
            <li><a href="/BAC2_IAGE_UNIVERSITE/views/promotions/index.php">Promotions</a></li>
            <li><a href="/BAC2_IAGE_UNIVERSITE/views/etudiants/index.php">Etudiants</a></li>
        </ul>
    </div>
</div>