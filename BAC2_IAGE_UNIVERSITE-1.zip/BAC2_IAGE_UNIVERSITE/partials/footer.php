<div id="footer">
    <p>&copy; 2025-2026 Université. Tous droits réservés.</p>
</div>