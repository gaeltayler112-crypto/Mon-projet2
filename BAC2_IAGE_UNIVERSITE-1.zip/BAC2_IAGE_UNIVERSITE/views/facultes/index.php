<?php
require_once __DIR__ . '/../../models/faculte_crud.php';
$facultes = afficher_facultes();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestion des Facultés</title>
    <link rel="stylesheet" href="../../style.css">
</head>
<body>
    <!-- sidebar -->
        <?php require_once __DIR__ . '/../../partials/sidebar.php'; ?>
    
        <!-- contenu principal -->

    <div id="content">

        <div id="title">
            <h1>Gestion des Facultés</h1>

            <a href="create.php" class="btn">Ajouter une faculté</a>
        </div>

        <table border="1">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nom</th>
                    <th>Nom du doyen</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($facultes && $facultes->rowCount() > 0): ?>
                    <?php while ($faculte = $facultes->fetch(PDO::FETCH_ASSOC)): ?>
                        <tr>
                            <td><?php echo $faculte['id']; ?></td>
                            <td><?php echo $faculte['nom']; ?></td>
                            <td><?php echo $faculte['nom_doyen']; ?></td>
                            <td>
                                <a href="update.php?id=<?php echo urlencode($faculte['id']); ?>" class="btn" style="color: green;">Modifier</a>
                                <a href="../../controllers/FaculteController.php?action=delete&id=<?php echo urlencode($faculte['id']); ?>" class="btn" style="color: red;" onclick="return confirm('Supprimer cette faculté ?');">Supprimer</a>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="4" style="text-align: center;">Aucune faculté enregistrée.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>

    </div>


    <!-- pied de page -->
    <?php require_once __DIR__ . '/../../partials/footer.php'; ?>
</body>
</html>