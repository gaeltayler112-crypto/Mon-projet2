<?php
require_once __DIR__ . '/../../models/faculte_crud.php';

$id = $_GET['id'] ?? $_POST['id'] ?? null;
$faculte = null;

if ($id !== null) {
    $statement = afficher_faculte_id($id);
    $faculte = $statement ? $statement->fetch(PDO::FETCH_ASSOC) : null;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modifier une faculté</title>
    <link rel="stylesheet" href="../../style.css">
</head>
<body>
    <!-- sidebar -->
        <?php require_once __DIR__ . '/../../partials/sidebar.php'; ?>
    
        <!-- contenu principal -->

    <div id="content">

        <div id="title">
            <h1>Modifier une faculté</h1>

            <a href="index.php" class="btn">Retour à la liste</a>
        </div>

        <?php if ($faculte): ?>
        <form action="../../controllers/FaculteController.php?action=update" method="POST">
            <input type="hidden" name="id" value="<?php echo htmlspecialchars($faculte['id']); ?>">
            <div class="form-group">
                <label for="nom">Nom de la faculté :</label>
                <input type="text" id="nom" name="nom" value="<?php echo htmlspecialchars($faculte['nom']); ?>" required>
            </div>
            <div class="form-group">
                <label for="nom_doyen">Nom du doyen :</label>
                <input type="text" id="nom_doyen" name="nom_doyen" value="<?php echo htmlspecialchars($faculte['nom_doyen']); ?>" required>
            </div>
            <button type="submit" id="submit">Modifier</button>
        </form>
        <?php else: ?>
            <p style="color: #fff; text-align: center;">Faculté introuvable.</p>
        <?php endif; ?>

    </div>


    <!-- pied de page -->
    <?php require_once __DIR__ . '/../../partials/footer.php'; ?>
</body>
</html>