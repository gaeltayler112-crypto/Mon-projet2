<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ajouter une faculté</title>
    <link rel="stylesheet" href="../../style.css">
</head>
<body>
    <!-- sidebar -->
        <?php require_once __DIR__ . '/../../partials/sidebar.php'; ?>
    
        <!-- contenu principal -->

    <div id="content">

        <div id="title">
            <h1>Ajouter une faculté</h1>

            <a href="index.php" class="btn">Retour à la liste</a>
        </div>

        <form action="../../controllers/FaculteController.php?action=store" method="POST">
            <div class="form-group">
                <label for="nom">Nom de la faculté :</label>
                <input type="text" id="nom" name="nom" required>
            </div>
            <div class="form-group">
                <label for="nom_doyen">Nom du doyen :</label>
                <input type="text" id="nom_doyen" name="nom_doyen" required>
            </div>
            <button type="submit" id="submit">Ajouter</button>
        </form>

    </div>


    <!-- pied de page -->
    <?php require_once __DIR__ . '/../../partials/footer.php'; ?>
</body>
</html>