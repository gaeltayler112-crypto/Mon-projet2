<?php

require_once __DIR__ . '/../models/faculte_crud.php';
$redirectIndex = '/BAC2_IAGE_UNIVERSITE/views/facultes/index.php';

$action = $_GET['action'] ?? null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if ($action === 'store') {
        $nom = $_POST['nom'] ?? '';
        $nom_doyen = $_POST['nom_doyen'] ?? '';
        ajouter_faculte($nom, $nom_doyen);
        header('Location: ' . $redirectIndex);
        exit;
    }
    if ($action === 'update') {
        $id = $_POST['id'] ?? null;
        $nom = $_POST['nom'] ?? '';
        $nom_doyen = $_POST['nom_doyen'] ?? '';
        modifier_faculte($id, $nom, $nom_doyen);
        header('Location: ' . $redirectIndex);
        exit;
    }
}

if ($action === 'delete') {
    $id = $_GET['id'] ?? null;
    if ($id) {
        supprimer_faculte($id);
    }
    header('Location: ' . $redirectIndex);
    exit;
}

header('Location: ' . $redirectIndex);
exit;
