<?php
// faculte.php
require_once __DIR__ . '/connexion_db.php';

// Ajouter une faculté
function ajouter_faculte($nom, $nom_doyen){
    $add = connexion()->prepare("INSERT INTO facultes(nom, nom_doyen) VALUES(?, ?)");
    $add->execute(array($nom, $nom_doyen));

    if($add){
        return true;
    }
}

// Afficher toutes les facultés
function afficher_facultes(){
    $select = connexion()->query("SELECT * FROM facultes ORDER BY id DESC");
    return $select;
}

// Afficher une faculté par son ID
function afficher_faculte_id($id){
    $select = connexion()->prepare("SELECT * FROM facultes WHERE id = ?");
    $select->execute(array($id));
    return $select;
}


// Modifier une faculté
function modifier_faculte($id, $nom, $nom_doyen){
    $update = connexion()->prepare("UPDATE facultes SET nom = ?, nom_doyen = ? WHERE id = ?");
    $update->execute(array($nom, $nom_doyen, $id));

    if($update){
        return true;
    }
}

// Supprimer une faculté
function supprimer_faculte($id){
    $delete = connexion()->prepare("DELETE FROM facultes WHERE id = ?");
    $delete->execute(array($id));

    if($delete){
        return true;
    }
}
?>
