<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Accueil</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <!-- sidebar -->
        <?php require_once __DIR__ . '/partials/sidebar.php'; ?>
    <!-- contenu principal -->

    <div id="content">

        <div id="title">
            <h1>Accueil</h1>
        </div>

    </div>

    <!-- pied de page -->
    <?php require_once __DIR__ . '/partials/footer.php'; ?>
    
</body>
</html>